import Meal from '../models/Meal.js';


export const getMeals = async (req, res, next) => {
  try {
    const { date, mealType } = req.query;
    let query = { user: req.user.id };

    if (date) {
      const startDate = new Date(date);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      query.date = { $gte: startDate, $lte: endDate };
    }

    if (mealType) {
      query.mealType = mealType;
    }

    const meals = await Meal.find(query).sort('-date');
    
    res.status(200).json({
      success: true,
      count: meals.length,
      data: meals
    });
  } catch (err) {
    next(err);
  }
};


export const getMeal = async (req, res, next) => {
  try {
    const meal = await Meal.findById(req.params.id);

    if (!meal) {
      return res.status(404).json({
        success: false,
        message: 'Meal not found'
      });
    }

    if (meal.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    res.status(200).json({
      success: true,
      data: meal
    });
  } catch (err) {
    next(err);
  }
};


export const createMeal = async (req, res, next) => {
  try {
    req.body.user = req.user.id;
    const meal = await Meal.create(req.body);

    res.status(201).json({
      success: true,
      data: meal
    });
  } catch (err) {
    next(err);
  }
};


export const updateMeal = async (req, res, next) => {
  try {
    let meal = await Meal.findById(req.params.id);

    if (!meal) {
      return res.status(404).json({
        success: false,
        message: 'Meal not found'
      });
    }

    if (meal.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    meal = await Meal.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: meal
    });
  } catch (err) {
    next(err);
  }
};


export const deleteMeal = async (req, res, next) => {
  try {
    const meal = await Meal.findById(req.params.id);

    if (!meal) {
      return res.status(404).json({
        success: false,
        message: 'Meal not found'
      });
    }

    if (meal.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    await meal.deleteOne();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};


export const getDailySummary = async (req, res, next) => {
  try {
    const { date } = req.query;
    const targetDate = date ? new Date(date) : new Date();
    targetDate.setHours(0, 0, 0, 0);
    
    const endDate = new Date(targetDate);
    endDate.setHours(23, 59, 59, 999);

    const meals = await Meal.find({
      user: req.user.id,
      date: { $gte: targetDate, $lte: endDate }
    });

    const summary = {
      date: targetDate,
      totalCalories: 0,
      totalProtein: 0,
      totalCarbs: 0,
      totalFats: 0,
      totalFiber: 0,
      totalSugar: 0,
      totalWater: 0,
      meals: meals.map(m => ({
        type: m.mealType,
        name: m.name,
        calories: m.totalCalories
      }))
    };

    meals.forEach(meal => {
      summary.totalCalories += meal.totalCalories || 0;
      summary.totalProtein += meal.totalProtein || 0;
      summary.totalCarbs += meal.totalCarbs || 0;
      summary.totalFats += meal.totalFats || 0;
      summary.totalFiber += meal.totalFiber || 0;
      summary.totalSugar += meal.totalSugar || 0;
      summary.totalWater += meal.waterIntake || 0;
    });

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (err) {
    next(err);
  }
};