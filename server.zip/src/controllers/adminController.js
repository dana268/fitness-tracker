const User = require('../models/User');
const Workout = require('../models/Workout');
const Meal = require('../models/Meal');
const Progress = require('../models/Progress');


const getAllUsers = async (req, res) => {
    try {
        const users = await User.find().select('-password');
        res.status(200).json({
            success: true,
            count: users.length,
            data: users
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select('-password');
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({
            success: true,
            data: user
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const updateUserRole = async (req, res) => {
    try {
        const { role } = req.body;
        
        if (!['user', 'admin'].includes(role)) {
            return res.status(400).json({ message: 'Invalid role' });
        }

        const user = await User.findByIdAndUpdate(
            req.params.id,
            { role },
            { new: true, runValidators: true }
        ).select('-password');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({
            success: true,
            data: user
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteUser = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        
        await Workout.deleteMany({ user: req.params.id });
        await Meal.deleteMany({ user: req.params.id });
        await Progress.deleteMany({ user: req.params.id });
        await user.deleteOne();

        res.status(200).json({
            success: true,
            message: 'User and all associated data deleted'
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const getStats = async (req, res) => {
    try {
        const totalUsers = await User.countDocuments();
        const totalWorkouts = await Workout.countDocuments();
        const totalMeals = await Meal.countDocuments();
        const adminCount = await User.countDocuments({ role: 'admin' });

        res.status(200).json({
            success: true,
            data: {
                totalUsers,
                totalWorkouts,
                totalMeals,
                adminCount,
                userCount: totalUsers - adminCount
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getAllUsers,
    getUserById,
    updateUserRole,
    deleteUser,
    getStats
};