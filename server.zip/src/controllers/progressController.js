import Progress from '../models/Progress.js';
import User from '../models/User.js';


export const getProgress = async (req, res, next) => {
  try {
    const { startDate, endDate, limit } = req.query;
    let query = { user: req.user.id };

    if (startDate && endDate) {
      query.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }

    let progressQuery = Progress.find(query).sort('-date');
    
    if (limit) {
      progressQuery = progressQuery.limit(parseInt(limit));
    }

    const progress = await progressQuery;
    
    res.status(200).json({
      success: true,
      count: progress.length,
      data: progress
    });
  } catch (err) {
    next(err);
  }
};


export const getProgressEntry = async (req, res, next) => {
  try {
    const progress = await Progress.findById(req.params.id);

    if (!progress) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    if (progress.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    res.status(200).json({
      success: true,
      data: progress
    });
  } catch (err) {
    next(err);
  }
};


export const createProgress = async (req, res, next) => {
  try {
    req.body.user = req.user.id;
    
    if (req.body.weight) {
      await User.findByIdAndUpdate(req.user.id, { weight: req.body.weight });
    }

    const progress = await Progress.create(req.body);

    res.status(201).json({
      success: true,
      data: progress
    });
  } catch (err) {
    next(err);
  }
};


export const updateProgress = async (req, res, next) => {
  try {
    let progress = await Progress.findById(req.params.id);

    if (!progress) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    if (progress.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    progress = await Progress.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: progress
    });
  } catch (err) {
    next(err);
  }
};


export const deleteProgress = async (req, res, next) => {
  try {
    const progress = await Progress.findById(req.params.id);

    if (!progress) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    if (progress.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    await progress.deleteOne();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};


export const getWeightStats = async (req, res, next) => {
  try {
    const { period = 'month' } = req.query;
    let startDate = new Date();
    
    if (period === 'week') {
      startDate.setDate(startDate.getDate() - 7);
    } else if (period === 'month') {
      startDate.setMonth(startDate.getMonth() - 1);
    } else if (period === 'year') {
      startDate.setFullYear(startDate.getFullYear() - 1);
    }

    const progress = await Progress.find({
      user: req.user.id,
      date: { $gte: startDate }
    }).sort('date');

    const weightData = progress.map(p => ({
      date: p.date,
      weight: p.weight,
      bmi: p.bmi,
      bodyFat: p.bodyFat
    }));

    res.status(200).json({
      success: true,
      data: {
        startWeight: weightData[0]?.weight || null,
        currentWeight: weightData[weightData.length - 1]?.weight || null,
        weightChange: weightData.length > 1 ? 
          weightData[weightData.length - 1].weight - weightData[0].weight : 0,
        history: weightData
      }
    });
  } catch (err) {
    next(err);
  }
};