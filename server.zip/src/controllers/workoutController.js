import Workout from '../models/Workout.js';

export const getWorkouts = async (req, res, next) => {
  try {
    const { startDate, endDate, type, difficulty } = req.query;
    let query = { user: req.user.id };

    // Filter by date range
    if (startDate && endDate) {
      query.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }

    // Filter by type
    if (type) {
      query.type = type;
    }

    // Filter by difficulty
    if (difficulty) {
      query.difficulty = difficulty;
    }

    const workouts = await Workout.find(query).sort('-date');
    
    res.status(200).json({
      success: true,
      count: workouts.length,
      data: workouts
    });
  } catch (err) {
    next(err);
  }
};


export const getWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Make sure user owns workout
    if (workout.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    res.status(200).json({
      success: true,
      data: workout
    });
  } catch (err) {
    next(err);
  }
};


export const createWorkout = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.user = req.user.id;

    const workout = await Workout.create(req.body);

    res.status(201).json({
      success: true,
      data: workout
    });
  } catch (err) {
    next(err);
  }
};


export const updateWorkout = async (req, res, next) => {
  try {
    let workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Make sure user owns workout
    if (workout.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    workout = await Workout.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: workout
    });
  } catch (err) {
    next(err);
  }
};


export const deleteWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Make sure user owns workout
    if (workout.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized'
      });
    }

    await workout.deleteOne();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};


export const getWorkoutStats = async (req, res, next) => {
  try {
    const workouts = await Workout.find({ user: req.user.id });

    const totalWorkouts = workouts.length;
    const totalDuration = workouts.reduce((sum, w) => sum + w.duration, 0);
    const totalCalories = workouts.reduce((sum, w) => sum + (w.caloriesBurned || 0), 0);
    const averageIntensity = workouts.reduce((sum, w) => sum + (w.intensity || 0), 0) / totalWorkouts || 0;

    // Group by type
    const byType = workouts.reduce((acc, w) => {
      acc[w.type] = (acc[w.type] || 0) + 1;
      return acc;
    }, {});

    res.status(200).json({
      success: true,
      data: {
        totalWorkouts,
        totalDuration,
        totalCalories,
        averageIntensity: averageIntensity.toFixed(1),
        byType,
        recentWorkouts: workouts.slice(0, 5)
      }
    });
  } catch (err) {
    next(err);
  }
};