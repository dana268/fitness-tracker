import mongoose from 'mongoose';

const foodItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Food name is required'],
    trim: true
  },
  quantity: {
    type: String,
    required: [true, 'Quantity is required']
  },
  calories: {
    type: Number,
    required: [true, 'Calories are required'],
    min: [0, 'Calories cannot be negative']
  },
  protein: {
    type: Number,
    default: 0,
    min: 0
  },
  carbs: {
    type: Number,
    default: 0,
    min: 0
  },
  fats: {
    type: Number,
    default: 0,
    min: 0
  },
  fiber: {
    type: Number,
    default: 0,
    min: 0
  },
  sugar: {
    type: Number,
    default: 0,
    min: 0
  }
});

const mealSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User is required']
  },
  mealType: {
    type: String,
    enum: ['breakfast', 'lunch', 'dinner', 'snack', 'brunch', 'pre-workout', 'post-workout'],
    required: [true, 'Meal type is required']
  },
  name: {
    type: String,
    required: [true, 'Please add meal name'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  foods: [foodItemSchema],
  totalCalories: {
    type: Number,
    default: 0,
    min: 0
  },
  totalProtein: {
    type: Number,
    default: 0,
    min: 0
  },
  totalCarbs: {
    type: Number,
    default: 0,
    min: 0
  },
  totalFats: {
    type: Number,
    default: 0,
    min: 0
  },
  totalFiber: {
    type: Number,
    default: 0,
    min: 0
  },
  totalSugar: {
    type: Number,
    default: 0,
    min: 0
  },
  waterIntake: {
    type: Number, // بالملليلتر
    default: 0,
    min: 0
  },
  notes: {
    type: String,
    maxlength: [500, 'Notes cannot exceed 500 characters']
  },
  rating: {
    type: Number,
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5']
  },
  date: {
    type: Date,
    default: Date.now
  },
  time: {
    type: String,
    default: () => new Date().toLocaleTimeString()
  },
  imageUrl: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Calculate totals before saving
mealSchema.pre('save', function(next) {
  this.totalCalories = this.foods.reduce((sum, food) => sum + (food.calories || 0), 0);
  this.totalProtein = this.foods.reduce((sum, food) => sum + (food.protein || 0), 0);
  this.totalCarbs = this.foods.reduce((sum, food) => sum + (food.carbs || 0), 0);
  this.totalFats = this.foods.reduce((sum, food) => sum + (food.fats || 0), 0);
  this.totalFiber = this.foods.reduce((sum, food) => sum + (food.fiber || 0), 0);
  this.totalSugar = this.foods.reduce((sum, food) => sum + (food.sugar || 0), 0);
  next();
});

// Index for efficient queries
mealSchema.index({ user: 1, date: -1 });
mealSchema.index({ mealType: 1, date: 1 });

export default mongoose.model('Meal', mealSchema);