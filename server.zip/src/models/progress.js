import mongoose from 'mongoose';

const bodyMeasurementSchema = new mongoose.Schema({
  chest: { type: Number, min: 0 },    // سم
  waist: { type: Number, min: 0 },    // سم
  hips: { type: Number, min: 0 },     // سم
  arms: { type: Number, min: 0 },     // سم
  thighs: { type: Number, min: 0 },   // سم
  calves: { type: Number, min: 0 }    // سم
});

const progressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User is required']
  },
  weight: {
    type: Number,
    required: [true, 'Please add weight'],
    min: [20, 'Weight must be at least 20kg'],
    max: [300, 'Weight must be less than 300kg']
  },
  bodyFat: {
    type: Number,
    min: [0, 'Body fat cannot be negative'],
    max: [60, 'Body fat cannot exceed 60%']
  },
  muscleMass: {
    type: Number,
    min: [0, 'Muscle mass cannot be negative'],
    max: [150, 'Muscle mass cannot exceed 150kg']
  },
  bmi: {
    type: Number,
    min: 0,
    max: 100
  },
  bmr: {
    type: Number, // Basal Metabolic Rate (سعرات حرارية)
    min: 0
  },
  visceralFat: {
    type: Number, // الدهون الحشوية
    min: 0,
    max: 30
  },
  bodyWater: {
    type: Number, // نسبة الماء في الجسم
    min: 0,
    max: 100
  },
  boneMass: {
    type: Number,
    min: 0
  },
  measurements: bodyMeasurementSchema,
  weeklyWorkoutCount: {
    type: Number,
    default: 0,
    min: 0
  },
  weeklyCaloriesBurned: {
    type: Number,
    default: 0,
    min: 0
  },
  weeklySteps: {
    type: Number,
    default: 0,
    min: 0
  },
  sleepHours: {
    type: Number,
    default: 0,
    min: 0,
    max: 24
  },
  energyLevel: {
    type: Number,
    min: [1, 'Energy level must be between 1-10'],
    max: [10, 'Energy level must be between 1-10']
  },
  mood: {
    type: String,
    enum: ['great', 'good', 'okay', 'tired', 'exhausted'],
    default: 'good'
  },
  notes: {
    type: String,
    maxlength: [500, 'Notes cannot exceed 500 characters']
  },
  photos: [{
    type: String, // URLs للصور
    url: String,
    caption: String,
    uploadedAt: Date
  }],
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Calculate BMI and BMR before saving
progressSchema.pre('save', async function(next) {
  // BMI calculation
  if (this.weight) {
    const user = await mongoose.model('User').findById(this.user);
    if (user && user.height) {
      const heightInMeters = user.height / 100;
      this.bmi = (this.weight / (heightInMeters * heightInMeters)).toFixed(1);
      
      // BMR calculation (Mifflin-St Jeor Equation)
      if (user.gender === 'male') {
        this.bmr = (10 * this.weight) + (6.25 * user.height) - (5 * user.age) + 5;
      } else if (user.gender === 'female') {
        this.bmr = (10 * this.weight) + (6.25 * user.height) - (5 * user.age) - 161;
      }
    }
  }
  next();
});

// Index for efficient queries
progressSchema.index({ user: 1, date: -1 });

export default mongoose.model('Progress', progressSchema);