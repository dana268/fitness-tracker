import mongoose from 'mongoose';

const exerciseSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Exercise name is required'],
    trim: true
  },
  sets: {
    type: Number,
    default: 1,
    min: [1, 'Sets must be at least 1']
  },
  reps: {
    type: Number,
    default: 0,
    min: [0, 'Reps cannot be negative']
  },
  weight: {
    type: Number,
    default: 0,
    min: [0, 'Weight cannot be negative']
  },
  duration: {
    type: Number, // بالثواني للتمارين الزمنية
    default: 0,
    min: [0, 'Duration cannot be negative']
  },
  restTime: {
    type: Number, // بالثواني
    default: 60,
    min: [0, 'Rest time cannot be negative']
  },
  completed: {
    type: Boolean,
    default: false
  }
});

const workoutSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User is required']
  },
  title: {
    type: String,
    required: [true, 'Please add a workout title'],
    trim: true,
    maxlength: [100, 'Title cannot exceed 100 characters']
  },
  description: {
    type: String,
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  type: {
    type: String,
    enum: ['cardio', 'strength', 'yoga', 'hiit', 'pilates', 'stretching', 'crossfit'],
    required: [true, 'Workout type is required']
  },
  difficulty: {
    type: String,
    enum: ['beginner', 'intermediate', 'advanced'],
    default: 'beginner'
  },
  duration: {
    type: Number, // بالدقائق
    required: [true, 'Please add duration in minutes'],
    min: [1, 'Duration must be at least 1 minute'],
    max: [480, 'Duration cannot exceed 8 hours']
  },
  caloriesBurned: {
    type: Number,
    default: 0,
    min: [0, 'Calories burned cannot be negative']
  },
  intensity: {
    type: Number,
    min: [1, 'Intensity must be between 1 and 10'],
    max: [10, 'Intensity must be between 1 and 10'],
    default: 5
  },
  exercises: [exerciseSchema],
  date: {
    type: Date,
    default: Date.now
  },
  location: {
    type: String,
    enum: ['gym', 'home', 'outdoor', 'park', 'office'],
    default: 'home'
  },
  notes: {
    type: String,
    maxlength: [1000, 'Notes cannot exceed 1000 characters']
  },
  tags: [{
    type: String,
    trim: true
  }],
  rating: {
    type: Number,
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5']
  },
  isPublic: {
    type: Boolean,
    default: false
  },
  completedAt: {
    type: Date
  }
}, {
  timestamps: true
});

// Index for faster queries
workoutSchema.index({ user: 1, date: -1 });
workoutSchema.index({ type: 1, difficulty: 1 });

// Calculate total volume (weight × sets × reps)
workoutSchema.methods.getTotalVolume = function() {
  return this.exercises.reduce((total, exercise) => {
    return total + (exercise.weight * exercise.sets * exercise.reps);
  }, 0);
};

// Calculate total exercises count
workoutSchema.methods.getTotalExercises = function() {
  return this.exercises.length;
};

export default mongoose.model('Workout', workoutSchema);