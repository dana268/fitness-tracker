import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Workouts = () => {
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    duration: '',
    caloriesBurned: '',
    difficulty: 'beginner',
    exercises: []
  });
  const [exercise, setExercise] = useState({ name: '', sets: '', reps: '', weight: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    fetchWorkouts();
  }, []);

  const fetchWorkouts = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/workouts');
      setWorkouts(res.data.data);
    } catch (error) {
      setError('Failed to load workouts');
    } finally {
      setLoading(false);
    }
  };

  const handleAddExercise = () => {
    if (exercise.name && exercise.sets && exercise.reps) {
      setFormData({
        ...formData,
        exercises: [...formData.exercises, exercise]
      });
      setExercise({ name: '', sets: '', reps: '', weight: '' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/workouts', formData);
      setWorkouts([res.data.data, ...workouts]);
      setShowForm(false);
      setFormData({
        title: '',
        description: '',
        duration: '',
        caloriesBurned: '',
        difficulty: 'beginner',
        exercises: []
      });
    } catch (error) {
      setError('Failed to create workout');
    }
  };

  const handleComplete = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/workouts/${id}/complete`);
      fetchWorkouts();
    } catch (error) {
      setError('Failed to complete workout');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this workout?')) {
      try {
        await axios.delete(`http://localhost:5000/api/workouts/${id}`);
        fetchWorkouts();
      } catch (error) {
        setError('Failed to delete workout');
      }
    }
  };

  if (loading) return <div style={styles.loading}>Loading workouts...</div>;

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.title}>💪 My Workouts</h1>
        <button style={styles.addBtn} onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : '+ Add Workout'}
        </button>
      </div>

      {error && <div style={styles.error}>{error}</div>}

      {showForm && (
        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="text"
            placeholder="Workout Title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            style={styles.input}
            required
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            style={styles.textarea}
          />
          <input
            type="number"
            placeholder="Duration (minutes)"
            value={formData.duration}
            onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
            style={styles.input}
            required
          />
          <input
            type="number"
            placeholder="Calories Burned"
            value={formData.caloriesBurned}
            onChange={(e) => setFormData({ ...formData, caloriesBurned: e.target.value })}
            style={styles.input}
            required
          />
          <select
            value={formData.difficulty}
            onChange={(e) => setFormData({ ...formData, difficulty: e.target.value })}
            style={styles.select}
          >
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>

          <div style={styles.exerciseSection}>
            <h3>Exercises</h3>
            <div style={styles.exerciseForm}>
              <input
                type="text"
                placeholder="Exercise name"
                value={exercise.name}
                onChange={(e) => setExercise({ ...exercise, name: e.target.value })}
                style={styles.smallInput}
              />
              <input
                type="number"
                placeholder="Sets"
                value={exercise.sets}
                onChange={(e) => setExercise({ ...exercise, sets: e.target.value })}
                style={styles.smallInput}
              />
              <input
                type="number"
                placeholder="Reps"
                value={exercise.reps}
                onChange={(e) => setExercise({ ...exercise, reps: e.target.value })}
                style={styles.smallInput}
              />
              <button type="button" onClick={handleAddExercise} style={styles.addExerciseBtn}>
                Add
              </button>
            </div>
            {formData.exercises.length > 0 && (
              <ul style={styles.exerciseList}>
                {formData.exercises.map((ex, idx) => (
                  <li key={idx}>{ex.name}: {ex.sets} sets × {ex.reps} reps</li>
                ))}
              </ul>
            )}
          </div>

          <button type="submit" style={styles.submitBtn}>Create Workout</button>
        </form>
      )}

      <div style={styles.workoutsGrid}>
        {workouts.length === 0 ? (
          <p style={styles.empty}>No workouts yet. Start your fitness journey!</p>
        ) : (
          workouts.map((workout) => (
            <div key={workout._id} style={styles.workoutCard}>
              <div style={styles.cardHeader}>
                <h3>{workout.title}</h3>
                <span style={{
                  ...styles.difficulty,
                  backgroundColor: workout.difficulty === 'beginner' ? '#27ae60' : 
                                  workout.difficulty === 'intermediate' ? '#f39c12' : '#e74c3c'
                }}>
                  {workout.difficulty}
                </span>
              </div>
              <p>{workout.description}</p>
              <div style={styles.stats}>
                <span>⏱️ {workout.duration} mins</span>
                <span>🔥 {workout.caloriesBurned} cal</span>
              </div>
              {workout.exercises.length > 0 && (
                <div>
                  <strong>Exercises:</strong>
                  <ul>
                    {workout.exercises.map((ex, idx) => (
                      <li key={idx}>{ex.name}: {ex.sets}×{ex.reps}</li>
                    ))}
                  </ul>
                </div>
              )}
              <div style={styles.cardActions}>
                {!workout.completed && (
                  <button onClick={() => handleComplete(workout._id)} style={styles.completeBtn}>
                    ✓ Complete
                  </button>
                )}
                <button onClick={() => handleDelete(workout._id)} style={styles.deleteBtn}>
                  🗑️ Delete
                </button>
              </div>
              {workout.completed && (
                <div style={styles.completedBadge}>✅ Completed</div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const styles = {
  container: { padding: '2rem', maxWidth: '1200px', margin: '0 auto', backgroundColor: '#f5f5f5', minHeight: 'calc(100vh - 200px)' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap' },
  title: { fontSize: '2rem', color: '#2c3e50' },
  addBtn: { backgroundColor: '#3498db', color: 'white', border: 'none', padding: '0.75rem 1.5rem', borderRadius: '5px', cursor: 'pointer', fontSize: '1rem' },
  form: { backgroundColor: 'white', padding: '1.5rem', borderRadius: '10px', marginBottom: '2rem', boxShadow: '0 2px 5px rgba(0,0,0,0.1)' },
  input: { width: '100%', padding: '0.75rem', marginBottom: '1rem', border: '1px solid #ddd', borderRadius: '5px', fontSize: '1rem', boxSizing: 'border-box' },
  textarea: { width: '100%', padding: '0.75rem', marginBottom: '1rem', border: '1px solid #ddd', borderRadius: '5px', fontSize: '1rem', boxSizing: 'border-box', minHeight: '80px' },
  select: { width: '100%', padding: '0.75rem', marginBottom: '1rem', border: '1px solid #ddd', borderRadius: '5px', fontSize: '1rem' },
  exerciseSection: { marginBottom: '1rem', padding: '1rem', backgroundColor: '#f8f9fa', borderRadius: '5px' },
  exerciseForm: { display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1rem' },
  smallInput: { flex: 1, padding: '0.5rem', border: '1px solid #ddd', borderRadius: '5px', fontSize: '0.9rem' },
  addExerciseBtn: { backgroundColor: '#27ae60', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '5px', cursor: 'pointer' },
  exerciseList: { marginTop: '0.5rem', paddingLeft: '1rem' },
  submitBtn: { backgroundColor: '#27ae60', color: 'white', border: 'none', padding: '0.75rem', borderRadius: '5px', cursor: 'pointer', fontSize: '1rem', width: '100%' },
  workoutsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '1.5rem' },
  workoutCard: { backgroundColor: 'white', padding: '1.5rem', borderRadius: '10px', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', position: 'relative' },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' },
  difficulty: { padding: '0.25rem 0.75rem', borderRadius: '20px', fontSize: '0.75rem', color: 'white' },
  stats: { display: 'flex', gap: '1rem', margin: '1rem 0', padding: '0.5rem 0', borderTop: '1px solid #eee', borderBottom: '1px solid #eee' },
  cardActions: { display: 'flex', gap: '0.5rem', marginTop: '1rem' },
  completeBtn: { backgroundColor: '#27ae60', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '5px', cursor: 'pointer', flex: 1 },
  deleteBtn: { backgroundColor: '#e74c3c', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '5px', cursor: 'pointer', flex: 1 },
  completedBadge: { position: 'absolute', top: '1rem', right: '1rem', backgroundColor: '#27ae60', color: 'white', padding: '0.25rem 0.5rem', borderRadius: '5px', fontSize: '0.75rem' },
  error: { backgroundColor: '#f8d7da', color: '#721c24', padding: '0.75rem', borderRadius: '5px', marginBottom: '1rem' },
  loading: { textAlign: 'center', padding: '3rem', fontSize: '1.2rem' },
  empty: { textAlign: 'center', padding: '3rem', color: '#7f8c8d' }
};

export default Workouts;