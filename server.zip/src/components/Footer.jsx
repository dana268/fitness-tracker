import React from 'react';

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <div style={styles.container}>
        <p>© 2026 Fitness App. All rights reserved.</p>
        <p>💪 Stay healthy, stay strong!</p>
      </div>
    </footer>
  );
};

const styles = {
  footer: { backgroundColor: '#34495e', color: 'white', padding: '1.5rem', textAlign: 'center', marginTop: 'auto' },
  container: { maxWidth: '1200px', margin: '0 auto' }
};

export default Footer;