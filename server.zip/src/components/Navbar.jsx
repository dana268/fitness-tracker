import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.container}>
        <Link to="/" style={styles.logo}>💪 Fitness App</Link>
        <div style={styles.links}>
          {user ? (
            <>
              <Link to="/dashboard" style={styles.link}>Dashboard</Link>
              <Link to="/workouts" style={styles.link}>Workouts</Link>
              <Link to="/meals" style={styles.link}>Meals</Link>
              <Link to="/progress" style={styles.link}>Progress</Link>
              {user.role === 'admin' && <Link to="/admin" style={styles.link}>Admin</Link>}
              <span style={styles.user}>👋 {user.name}</span>
              <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" style={styles.link}>Login</Link>
              <Link to="/register" style={styles.link}>Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

const styles = {
  nav: { backgroundColor: '#2c3e50', padding: '1rem', position: 'sticky', top: 0, zIndex: 1000 },
  container: { maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' },
  logo: { color: 'white', fontSize: '1.5rem', textDecoration: 'none', fontWeight: 'bold' },
  links: { display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' },
  link: { color: 'white', textDecoration: 'none', padding: '0.5rem' },
  user: { marginLeft: '1rem', color: '#3498db', fontWeight: 'bold' },
  logoutBtn: { backgroundColor: '#e74c3c', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '5px', cursor: 'pointer' }
};

export default Navbar;