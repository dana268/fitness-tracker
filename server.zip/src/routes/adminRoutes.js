import express from 'express';
import {
  getUsers,
  getUser,
  updateUserRole,
  deleteUser,
  getDashboardStats
} from '../controllers/adminController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

// All admin routes require authentication and admin role
router.use(protect);
router.use(authorize('admin'));

router.get('/users', getUsers);
router.get('/stats', getDashboardStats);
router.route('/users/:id')
  .get(getUser)
  .delete(deleteUser);
router.put('/users/:id/role', updateUserRole);

export default router;