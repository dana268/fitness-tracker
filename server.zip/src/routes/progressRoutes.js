import express from 'express';
import {
  getProgress,
  getProgressEntry,
  createProgress,
  updateProgress,
  deleteProgress,
  getWeightStats
} from '../controllers/progressController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
  .get(protect, getProgress)
  .post(protect, createProgress);

router.get('/stats/weight', protect, getWeightStats);

router.route('/:id')
  .get(protect, getProgressEntry)
  .put(protect, updateProgress)
  .delete(protect, deleteProgress);

export default router;